from setuptools import setup, find_packages

setup(
    name = 'myownpypipackage',
    version = '0.0.1',
    license = 'MIT',
    description = 'paquete de prueba',
    author = "Roberto Carro Gastélum",
    packages = find_packages(),
    url = "https://github.com/robcg1102/pypipackage"
)